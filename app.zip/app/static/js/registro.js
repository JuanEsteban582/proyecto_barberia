function mostrarAlerta(mensaje) {
    var alerta = document.getElementById('alerta');
    alerta.innerHTML = mensaje;
    alerta.classList.remove('oculto');
}

// Para ocultar la alerta
function ocultarAlerta() {
    var alerta = document.getElementById('alerta');
    alerta.classList.add('oculto');
}